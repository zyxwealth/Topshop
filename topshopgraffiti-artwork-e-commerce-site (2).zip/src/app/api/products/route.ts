import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq, desc, asc, sql, and, like } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const category = searchParams.get("category");
  const sort = searchParams.get("sort") || "newest";
  const search = searchParams.get("search");
  const featured = searchParams.get("featured");

  // Build conditions
  const conditions = [];
  if (category) {
    conditions.push(eq(categories.slug, category));
  }
  if (search) {
    conditions.push(like(products.name, `%${search}%`));
  }
  if (featured === "true") {
    conditions.push(eq(products.featured, true));
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  // Determine sort order
  const sortOrders: Record<string, ReturnType<typeof desc> | ReturnType<typeof asc>> = {
    "price-asc": asc(products.price),
    "price-desc": desc(products.price),
    "name": asc(products.name),
    "newest": desc(products.id),
  };
  const orderClause = sortOrders[sort] || sortOrders["newest"];

  const result = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      price: products.price,
      originalPrice: products.originalPrice,
      imageUrl: products.imageUrl,
      medium: products.medium,
      dimensions: products.dimensions,
      featured: products.featured,
      inStock: products.inStock,
      categoryId: products.categoryId,
      category: categories.name,
      categorySlug: categories.slug,
      reviewCount: sql<number>`count(${reviews.id})`,
      avgRating: sql<number>`coalesce(avg(${reviews.rating}), 0)`,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(reviews, eq(products.id, reviews.productId))
    .where(whereClause)
    .groupBy(products.id, categories.name, categories.slug)
    .orderBy(orderClause);

  return NextResponse.json(result);
}
