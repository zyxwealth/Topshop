import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const product = await db
    .select()
    .from(products)
    .where(eq(products.slug, id))
    .limit(1);

  if (!product.length) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const category = product[0].categoryId
    ? await db
        .select()
        .from(categories)
        .where(eq(categories.id, product[0].categoryId!))
        .limit(1)
    : [];

  const productReviews = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, product[0].id))
    .orderBy(reviews.createdAt);

  // Related products (same category, excluding current)
  const related = product[0].categoryId
    ? await db
        .select({
          id: products.id,
          name: products.name,
          slug: products.slug,
          price: products.price,
          originalPrice: products.originalPrice,
          imageUrl: products.imageUrl,
          medium: products.medium,
        })
        .from(products)
        .where(eq(products.categoryId, product[0].categoryId!))
        .limit(4)
    : [];

  const filteredRelated = related.filter((r) => r.id !== product[0].id);

  return NextResponse.json({
    ...product[0],
    category: category[0] || null,
    reviews: productReviews,
    related: filteredRelated,
  });
}
