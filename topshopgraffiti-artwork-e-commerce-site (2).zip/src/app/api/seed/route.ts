import { seed } from "@/db/seed";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const result = await seed();
    return NextResponse.json(result);
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { error: "Seed failed", details: String(error) },
      { status: 500 }
    );
  }
}
