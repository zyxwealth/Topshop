import { db } from "@/db";
import { orders } from "@/db/schema";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, firstName, lastName, address, city, state, zip, total, items } = body;

    if (!email || !firstName || !lastName || !address || !city || !state || !zip) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      );
    }

    const order = await db
      .insert(orders)
      .values({
        email,
        firstName,
        lastName,
        address,
        city,
        state,
        zip,
        total: total.toFixed(2),
        items,
        status: "confirmed",
      })
      .returning();

    return NextResponse.json({ orderId: order[0].id, status: "confirmed" });
  } catch {
    return NextResponse.json(
      { error: "Failed to process order" },
      { status: 500 }
    );
  }
}
