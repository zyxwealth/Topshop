import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Sparkles, Shield, Truck } from "lucide-react";
import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function getFeaturedProducts() {
  return db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      price: products.price,
      originalPrice: products.originalPrice,
      imageUrl: products.imageUrl,
      medium: products.medium,
      categoryId: products.categoryId,
      category: categories.name,
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.featured, true))
    .orderBy(desc(products.id))
    .limit(4);
}

async function getAllCategories() {
  return db.select().from(categories);
}

export default async function HomePage() {
  const [featured, cats] = await Promise.all([
    getFeaturedProducts(),
    getAllCategories(),
  ]);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <Image
            src="/images/hero.jpg"
            alt="Topshopgraffiti Art"
            fill
            className="object-cover"
            priority
            quality={90}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-dark via-brand-dark/80 to-brand-dark/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-transparent to-transparent" />
        </div>

        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-2xl">
            <span className="inline-block text-brand-gold text-xs font-semibold tracking-[0.3em] uppercase mb-6 animate-fade-in-up">
              Hand Crafted Artwork
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-serif font-bold leading-tight mb-6 animate-fade-in-up stagger-1">
              Where the
              <br />
              <span className="text-brand-gold italic">Streets</span> Meet
              <br />
              the Canvas
            </h1>
            <p className="text-white/60 text-base sm:text-lg font-light leading-relaxed mb-10 max-w-lg animate-fade-in-up stagger-2">
              Discover one-of-a-kind graffiti and urban artwork crafted for
              discerning collectors. Each piece is a statement of raw expression
              and uncompromising vision.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up stagger-3">
              <Link
                href="/shop"
                className="inline-flex items-center justify-center gap-2 bg-brand-gold text-brand-dark px-8 py-4 text-sm font-bold tracking-wider uppercase hover:bg-brand-gold-light transition-colors"
              >
                Explore Collection
                <ArrowRight size={16} />
              </Link>
              <Link
                href="/shop?category=limited-edition-prints"
                className="inline-flex items-center justify-center gap-2 border border-white/20 text-white px-8 py-4 text-sm font-light tracking-wider uppercase hover:border-brand-gold/50 hover:text-brand-gold transition-all"
              >
                Limited Editions
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/20 rounded-full flex items-start justify-center p-1.5">
            <div className="w-1.5 h-3 bg-brand-gold rounded-full" />
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-brand-gold text-xs font-semibold tracking-[0.3em] uppercase">
              Curated for You
            </span>
            <h2 className="text-3xl lg:text-5xl font-serif font-bold mt-3">
              Featured Collections
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cats.slice(0, 3).map((cat, i) => (
              <Link
                key={cat.id}
                href={`/shop?category=${cat.slug}`}
                className={`group relative aspect-[3/4] rounded-xl overflow-hidden opacity-0 animate-fade-in-up stagger-${Math.min(i + 1, 6)}`}
                style={{ animationFillMode: "forwards" }}
              >
                <Image
                  src={cat.imageUrl || "/images/hero.jpg"}
                  alt={cat.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                  <h3 className="text-xl lg:text-2xl font-serif font-semibold mb-2 group-hover:text-brand-gold transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-white/50 text-sm font-light line-clamp-2">
                    {cat.description}
                  </p>
                  <span className="inline-flex items-center gap-1 text-brand-gold text-xs font-semibold tracking-wider uppercase mt-4 group-hover:gap-2 transition-all">
                    View Collection <ArrowRight size={12} />
                  </span>
                </div>
              </Link>
            ))}
          </div>

          {/* More categories row */}
          {cats.length > 3 && (
            <div className="grid grid-cols-2 gap-6 mt-6">
              {cats.slice(3, 5).map((cat) => (
                <Link
                  key={cat.id}
                  href={`/shop?category=${cat.slug}`}
                  className="group relative aspect-[16/9] rounded-xl overflow-hidden hidden lg:block"
                >
                  <Image
                    src={cat.imageUrl || "/images/hero.jpg"}
                    alt={cat.name}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                    sizes="50vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-lg font-serif font-semibold group-hover:text-brand-gold transition-colors">
                      {cat.name}
                    </h3>
                    <span className="inline-flex items-center gap-1 text-brand-gold text-xs font-semibold tracking-wider uppercase mt-2 group-hover:gap-2 transition-all">
                      View Collection <ArrowRight size={12} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-brand-charcoal/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="text-brand-gold text-xs font-semibold tracking-[0.3em] uppercase">
                Handpicked
              </span>
              <h2 className="text-3xl lg:text-4xl font-serif font-bold mt-2">
                Editor&apos;s Picks
              </h2>
            </div>
            <Link
              href="/shop"
              className="hidden sm:inline-flex items-center gap-2 text-brand-gold text-sm font-light tracking-wider hover:gap-3 transition-all"
            >
              View All <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product, i) => (
              <Link
                key={product.id}
                href={`/product/${product.slug}`}
                className={`group block opacity-0 animate-fade-in-up stagger-${Math.min(i + 1, 6)}`}
                style={{ animationFillMode: "forwards" }}
              >
                <div className="relative bg-brand-charcoal rounded-lg overflow-hidden border border-white/5 hover:border-brand-gold/20 transition-all duration-500">
                  <div className="img-zoom relative aspect-[4/5] bg-brand-dark">
                    <Image
                      src={product.imageUrl}
                      alt={product.name}
                      fill
                      className="object-cover"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-500" />
                    {product.originalPrice && (
                      <span className="absolute top-3 left-3 bg-red-500/90 text-white text-[10px] font-bold tracking-wider uppercase px-2.5 py-1">
                        Sale
                      </span>
                    )}
                  </div>
                  <div className="p-4">
                    {product.category && (
                      <p className="text-brand-gold/70 text-[10px] font-semibold tracking-[0.15em] uppercase mb-1">
                        {product.category}
                      </p>
                    )}
                    <h3 className="text-white font-serif font-medium text-base group-hover:text-brand-gold transition-colors">
                      {product.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-white font-semibold text-sm">
                        ${parseFloat(product.price).toLocaleString()}
                      </span>
                      {product.originalPrice && (
                        <span className="text-white/30 text-xs line-through">
                          ${parseFloat(product.originalPrice).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 text-brand-gold text-sm font-light tracking-wider"
            >
              View All Products <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* Value Props */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-14 h-14 mx-auto mb-5 rounded-full border border-brand-gold/30 flex items-center justify-center">
                <Sparkles className="text-brand-gold" size={22} />
              </div>
              <h3 className="text-lg font-serif font-semibold mb-3">
                Authentic Pieces
              </h3>
              <p className="text-white/40 text-sm font-light leading-relaxed">
                Every artwork is hand crafted by verified artists. Each piece
                comes with a certificate of authenticity and provenance
                documentation.
              </p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 mx-auto mb-5 rounded-full border border-brand-gold/30 flex items-center justify-center">
                <Shield className="text-brand-gold" size={22} />
              </div>
              <h3 className="text-lg font-serif font-semibold mb-3">
                Museum-Quality
              </h3>
              <p className="text-white/40 text-sm font-light leading-relaxed">
                Premium materials and archival techniques ensure your artwork
                will maintain its vibrancy for generations. We guarantee
                quality.
              </p>
            </div>
            <div className="text-center">
              <div className="w-14 h-14 mx-auto mb-5 rounded-full border border-brand-gold/30 flex items-center justify-center">
                <Truck className="text-brand-gold" size={22} />
              </div>
              <h3 className="text-lg font-serif font-semibold mb-3">
                White Glove Delivery
              </h3>
              <p className="text-white/40 text-sm font-light leading-relaxed">
                Custom crating and insured shipping worldwide. Our white glove
                service delivers and installs your artwork with the care it
                deserves.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://lh3.googleusercontent.com/pw/AP1GczMY82IWTdRjoG871YBPykt76Zs5SanWaOQTizSbkVRETEmoDJFh7zEc9OCMfnZqv_SSsndrtu_SFf5mPMThy1lAikwwMSNrnAkc608vwGGvjNLv3L5P=w940"
            alt="Art collection"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-brand-dark/85" />
        </div>
        <div className="relative max-w-3xl mx-auto text-center px-4">
          <h2 className="text-3xl lg:text-5xl font-serif font-bold mb-6">
            Commission a
            <span className="text-brand-gold italic"> Masterpiece</span>
          </h2>
          <p className="text-white/50 font-light leading-relaxed mb-8">
            Work directly with our artists to create a bespoke piece tailored to
            your space, vision, and aesthetic. From intimate studies to
            monumental installations, we bring your vision to life.
          </p>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 bg-brand-gold text-brand-dark px-8 py-4 text-sm font-bold tracking-wider uppercase hover:bg-brand-gold-light transition-colors"
          >
            Start Your Commission
            <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}
