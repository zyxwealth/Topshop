"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { ShoppingBag, Heart, Share2, ArrowRight, ChevronRight, Minus, Plus, Check } from "lucide-react";
import { ImageGallery } from "@/components/ImageGallery";
import { ReviewStars } from "@/components/ReviewStars";
import { useCart } from "@/lib/cart-context";

interface Review {
  id: number;
  authorName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

interface Product {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: string;
  originalPrice: string | null;
  medium: string | null;
  dimensions: string | null;
  imageUrl: string;
  images: string[];
  featured: boolean;
  inStock: boolean;
  category: { name: string; slug: string } | null;
  reviews: Review[];
  related: {
    id: number;
    name: string;
    slug: string;
    price: string;
    originalPrice: string | null;
    imageUrl: string;
    medium: string | null;
  }[];
}

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params.id as string;
  const { addItem } = useCart();

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<"description" | "details" | "reviews">("description");

  useEffect(() => {
    setLoading(true);
    fetch(`/api/products/${slug}`)
      .then((r) => {
        if (!r.ok) throw new Error("Not found");
        return r.json();
      })
      .then(setProduct)
      .catch(() => setProduct(null))
      .finally(() => setLoading(false));
  }, [slug]);

  const handleAddToCart = () => {
    if (!product) return;
    for (let i = 0; i < quantity; i++) {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
      });
    }
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="aspect-[4/5] shimmer rounded-lg" />
          <div className="space-y-4">
            <div className="h-4 w-24 shimmer rounded" />
            <div className="h-8 w-3/4 shimmer rounded" />
            <div className="h-6 w-32 shimmer rounded" />
            <div className="h-24 shimmer rounded mt-6" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="text-2xl font-serif font-bold mb-4">Artwork Not Found</h1>
        <p className="text-white/40 font-light mb-8">
          The piece you&apos;re looking for doesn&apos;t exist or has been removed.
        </p>
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 bg-brand-gold text-brand-dark px-6 py-3 text-sm font-bold tracking-wider uppercase hover:bg-brand-gold-light transition-colors"
        >
          Back to Shop <ArrowRight size={14} />
        </Link>
      </div>
    );
  }

  const avgRating =
    product.reviews.length > 0
      ? product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length
      : 0;

  return (
    <div className="animate-fade-in">
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <nav className="flex items-center gap-2 text-xs text-white/30 font-light">
          <Link href="/" className="hover:text-brand-gold transition-colors">
            Home
          </Link>
          <ChevronRight size={10} />
          <Link href="/shop" className="hover:text-brand-gold transition-colors">
            Shop
          </Link>
          {product.category && (
            <>
              <ChevronRight size={10} />
              <Link
                href={`/shop?category=${product.category.slug}`}
                className="hover:text-brand-gold transition-colors"
              >
                {product.category.name}
              </Link>
            </>
          )}
          <ChevronRight size={10} />
          <span className="text-white/60">{product.name}</span>
        </nav>
      </div>

      {/* Product */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Gallery */}
          <ImageGallery
            images={Array.isArray(product.images) ? product.images : []}
            name={product.name}
          />

          {/* Details */}
          <div className="space-y-6">
            {product.category && (
              <p className="text-brand-gold text-xs font-semibold tracking-[0.2em] uppercase">
                {product.category.name}
              </p>
            )}

            <h1 className="text-3xl lg:text-4xl font-serif font-bold">
              {product.name}
            </h1>

            {/* Rating */}
            {product.reviews.length > 0 && (
              <div className="flex items-center gap-3">
                <ReviewStars rating={Math.round(avgRating)} size={16} />
                <span className="text-white/40 text-sm font-light">
                  {avgRating.toFixed(1)} ({product.reviews.length} review
                  {product.reviews.length !== 1 ? "s" : ""})
                </span>
              </div>
            )}

            {/* Price */}
            <div className="flex items-center gap-3">
              <span className="text-2xl font-serif font-bold text-brand-gold">
                ${parseFloat(product.price).toLocaleString()}
              </span>
              {product.originalPrice && (
                <>
                  <span className="text-white/30 line-through text-lg">
                    ${parseFloat(product.originalPrice).toLocaleString()}
                  </span>
                  <span className="bg-red-500/20 text-red-400 text-xs font-semibold px-2 py-0.5">
                    Save ${(parseFloat(product.originalPrice) - parseFloat(product.price)).toLocaleString()}
                  </span>
                </>
              )}
            </div>

            {/* Description excerpt */}
            <p className="text-white/50 font-light leading-relaxed text-sm">
              {product.description.slice(0, 180)}...
            </p>

            {/* Quantity + Add to Cart */}
            <div className="flex items-center gap-4 pt-4">
              <div className="flex items-center border border-white/10">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 flex items-center justify-center text-white/50 hover:text-brand-gold transition-colors"
                >
                  <Minus size={14} />
                </button>
                <span className="w-10 text-center text-sm">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center text-white/50 hover:text-brand-gold transition-colors"
                >
                  <Plus size={14} />
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={added}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 text-sm font-bold tracking-wider uppercase transition-all ${
                  added
                    ? "bg-green-600 text-white"
                    : "bg-brand-gold text-brand-dark hover:bg-brand-gold-light"
                }`}
              >
                {added ? (
                  <>
                    <Check size={16} />
                    Added to Cart
                  </>
                ) : (
                  <>
                    <ShoppingBag size={16} />
                    Add to Cart
                  </>
                )}
              </button>
            </div>

            {/* Wishlist + Share */}
            <div className="flex items-center gap-4 pt-2">
              <button className="flex items-center gap-2 text-white/30 text-xs font-light hover:text-brand-gold transition-colors">
                <Heart size={14} />
                Add to Wishlist
              </button>
              <button className="flex items-center gap-2 text-white/30 text-xs font-light hover:text-brand-gold transition-colors">
                <Share2 size={14} />
                Share
              </button>
            </div>

            {/* Product info tabs */}
            <div className="border-t border-white/10 pt-6 mt-6">
              <div className="flex gap-6">
                {(["description", "details", "reviews"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`text-sm font-light tracking-wider uppercase pb-2 border-b-2 transition-all ${
                      activeTab === tab
                        ? "text-brand-gold border-brand-gold"
                        : "text-white/30 border-transparent hover:text-white/60"
                    }`}
                  >
                    {tab} {tab === "reviews" && `(${product.reviews.length})`}
                  </button>
                ))}
              </div>

              <div className="mt-6">
                {activeTab === "description" && (
                  <p className="text-white/50 font-light leading-relaxed text-sm animate-fade-in">
                    {product.description}
                  </p>
                )}

                {activeTab === "details" && (
                  <div className="space-y-3 animate-fade-in">
                    {product.medium && (
                      <div className="flex items-center gap-4">
                        <span className="text-white/30 text-sm w-28">Medium</span>
                        <span className="text-white/70 text-sm font-light">{product.medium}</span>
                      </div>
                    )}
                    {product.dimensions && (
                      <div className="flex items-center gap-4">
                        <span className="text-white/30 text-sm w-28">Dimensions</span>
                        <span className="text-white/70 text-sm font-light">{product.dimensions}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-4">
                      <span className="text-white/30 text-sm w-28">Availability</span>
                      <span className={`text-sm font-light ${product.inStock ? "text-green-400" : "text-red-400"}`}>
                        {product.inStock ? "In Stock" : "Sold Out"}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-white/30 text-sm w-28">Authenticity</span>
                      <span className="text-white/70 text-sm font-light">Certificate Included</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-white/30 text-sm w-28">Shipping</span>
                      <span className="text-white/70 text-sm font-light">Free White Glove Delivery</span>
                    </div>
                  </div>
                )}

                {activeTab === "reviews" && (
                  <div className="space-y-6 animate-fade-in">
                    {product.reviews.length === 0 ? (
                      <p className="text-white/30 font-light text-sm">
                        No reviews yet. Be the first to share your thoughts.
                      </p>
                    ) : (
                      product.reviews.map((review) => (
                        <div
                          key={review.id}
                          className="border-b border-white/5 pb-4 last:border-0"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-brand-gold/20 flex items-center justify-center text-brand-gold text-xs font-bold">
                                {review.authorName.charAt(0)}
                              </div>
                              <span className="text-sm font-medium">
                                {review.authorName}
                              </span>
                            </div>
                            <ReviewStars rating={review.rating} size={12} />
                          </div>
                          <p className="text-white/40 text-sm font-light leading-relaxed ml-11">
                            {review.comment}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {product.related && product.related.length > 0 && (
          <div className="mt-24">
            <h2 className="text-2xl font-serif font-bold mb-8">
              You May Also Like
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {product.related.slice(0, 3).map((rel) => (
                <Link
                  key={rel.id}
                  href={`/product/${rel.slug}`}
                  className="group block"
                >
                  <div className="relative aspect-[4/5] bg-brand-charcoal rounded-lg overflow-hidden img-zoom">
                    <Image
                      src={rel.imageUrl}
                      alt={rel.name}
                      fill
                      className="object-cover"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-500" />
                  </div>
                  <div className="mt-3">
                    <h3 className="text-white font-serif group-hover:text-brand-gold transition-colors">
                      {rel.name}
                    </h3>
                    <span className="text-brand-gold text-sm">
                      ${parseFloat(rel.price).toLocaleString()}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
